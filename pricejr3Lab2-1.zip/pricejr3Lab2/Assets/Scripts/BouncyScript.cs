﻿using UnityEngine;
using System.Collections;

public class BouncyScript : MonoBehaviour
{


    float value;

    public void Bounce()
    {

        print("IN BOUNCE!!!");
        transform.Translate(Vector3.forward * 25.0f * Time.deltaTime);
    }

    public void DropMessage(float value = 16.0f)
    {

      
        Rigidbody rigBod = GetComponent<Rigidbody>();
        rigBod.useGravity = true;
        print("THE " + gameObject.name + " WAS DROPPED, SO IT CAN MOVE!!"  + value + ".");
    }

}
