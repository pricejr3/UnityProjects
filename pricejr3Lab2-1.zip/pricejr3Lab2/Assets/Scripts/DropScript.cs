﻿using UnityEngine;
using System.Collections;

public class DropScript : MonoBehaviour {



    public void Drop()
    {
        GameObject d4 = GameObject.Find("Dropper4");
        Rigidbody rigBod = d4.GetComponent<Rigidbody>();
        rigBod.useGravity = true;
    }
}
