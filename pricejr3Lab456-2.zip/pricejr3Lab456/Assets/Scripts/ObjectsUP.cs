﻿using UnityEngine;
using System.Collections;

public class ObjectsUP : MonoBehaviour
{

    public float hoverForce = 3.0f;
    private GameObject[] boxes;

    Vector3 Direction;
    public float movespeed = 588.0f;
    Rigidbody rg;
  

    void OnTriggerEnter(Collider other)
    {


    }

    void OnTriggerStay(Collider other)
    {
        Direction = Vector3.right;

        float randx = Random.Range(-0.05F, 0.05F);
        float randy = Random.Range(-0.125F, 0.125F);
        float randz = Random.Range(-0.004F, 0.004F);


        boxes = GameObject.FindGameObjectsWithTag("MoveUp");
        foreach (GameObject r in boxes)
        {
            rg = r.GetComponent<Rigidbody>();

            rg.useGravity = false;
            r.transform.Translate(0.05f, 0.125f, 0.0f);
        }

      

    }

   

}