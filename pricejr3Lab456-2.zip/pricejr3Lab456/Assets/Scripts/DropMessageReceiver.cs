﻿using UnityEngine;
using System.Collections;

public class DropMessageReceiver : MonoBehaviour {


    float value;


    public void DropMessage(float value = 5.0f)
    {
        Rigidbody rigBod = GetComponent<Rigidbody>();
        rigBod.useGravity = true;
        print(gameObject.name + " dropped with a " + value + ".");
    }

}
