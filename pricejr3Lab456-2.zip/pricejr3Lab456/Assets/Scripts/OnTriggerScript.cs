﻿using UnityEngine;
using System.Collections;

public class OnTriggerScript : MonoBehaviour {

    void OnTriggerEnter(Collider other)
    {
         Debug.Log("Trigger Enter " + other.gameObject.name);
    }

    void OnTriggerStay(Collider other)
    {
        Debug.Log("Trigger Stay " + other.gameObject.name);
    }

    void OnTriggerExit(Collider other)
    {
        Debug.Log("Trigger Exited " + other.gameObject.name);
    }

}
