﻿using UnityEngine;
using System.Collections;

public class WASDMovement : MonoBehaviour {


 
  
    public float speed = 5.0f;

 
    void Update()
    {
       

        if (Input.GetKey(KeyCode.W))
        {
            
            transform.position += Vector3.forward * speed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.S))
        {

            transform.position += Vector3.back * speed/3 * Time.deltaTime;
        }

        else if (Input.GetKey(KeyCode.A))
        {

            transform.position += Vector3.left *  ((speed*2)/3) * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.position += Vector3.right * ((speed * 2) / 3) * Time.deltaTime;
       
        }
      

       
    }
}