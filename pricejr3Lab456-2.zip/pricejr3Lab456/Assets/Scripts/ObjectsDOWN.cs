﻿using UnityEngine;
using System.Collections;

public class ObjectsDOWN : MonoBehaviour {

    public float hoverForce = 3.0f;
    private GameObject[] boxes;

    Vector3 Direction;
    public float movespeed = 588.0f;
    Rigidbody rg;



    void OnTriggerEnter(Collider other)
    {

        boxes = GameObject.FindGameObjectsWithTag("MoveUp");

        foreach (GameObject r in boxes)
        {

            rg = r.GetComponent<Rigidbody>();

            rg.useGravity = true;
        }

    }




}