﻿using UnityEngine;
using System.Collections;

public class BulletCollision : MonoBehaviour {

    public GameObject explosionPrefab;
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag.Equals("enemy"))
        {


            ContactPoint contact = collision.contacts[0];
            Quaternion rot = Quaternion.FromToRotation(Vector3.up, contact.normal);
            Vector3 pos = contact.point;
            GameObject explosion = Instantiate(explosionPrefab, pos, rot) as GameObject;
            Destroy(explosion, 3.0f);


            // Destroy the robot
            Destroy(collision.gameObject);

            // Destroy the bullet
            Destroy(gameObject);


        }
    }

} //