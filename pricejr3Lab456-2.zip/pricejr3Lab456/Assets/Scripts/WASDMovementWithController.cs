﻿using UnityEngine;
using System.Collections;


[RequireComponent(typeof(CharacterController))]
public class WASDMovementWithController : MonoBehaviour {


    public float speed = 5.0f;
    CharacterController controller;



    void Start()
    {
        controller = GetComponent<CharacterController>();
    

    }

    void Update()
    {

        //Vector3 moveVector = transform.TransformDirection(Vector3.forward );
        //controller.Move(moveVector * FowardSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.W))
        {


            Vector3 moveVector = transform.TransformDirection(Vector3.forward);
            controller.Move(moveVector * speed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.S))
        {
            Vector3 moveVector = transform.TransformDirection(Vector3.back);
            controller.Move(moveVector * speed/3 * Time.deltaTime);
        }

        else if (Input.GetKey(KeyCode.A))
        {
            Vector3 moveVector = transform.TransformDirection(Vector3.left);
            controller.Move(moveVector * ((speed * 2) / 3) * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.D))
        {

            Vector3 moveVector = transform.TransformDirection(Vector3.right);
            controller.Move(moveVector * ((speed * 2) / 3) * Time.deltaTime);
    

        }



    }
}