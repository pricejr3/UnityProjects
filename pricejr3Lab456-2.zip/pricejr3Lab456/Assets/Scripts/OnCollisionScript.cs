﻿using UnityEngine;
using System.Collections;

public class OnCollisionScript : MonoBehaviour 
{

  

    void OnCollisionEnter(Collision collision) {

        Debug.Log("Collision Enter: " + collision.gameObject.name);
    }

    void OnCollisionStay(Collision collision)
    {
        Debug.Log("Collision Still Occurring with: " + collision.gameObject.name);
    }

    void OnCollisionExit(Collision collision)
    {
        Debug.Log("Exited Collision with: " + collision.gameObject.name);
    }


}
