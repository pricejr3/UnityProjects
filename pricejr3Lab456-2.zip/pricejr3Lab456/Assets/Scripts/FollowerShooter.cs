﻿using UnityEngine;
using System.Collections;

public class FollowerShooter : MonoBehaviour {

    public GameObject projectile;
    public float bulletSpeed = 60.0f;




    	IEnumerator Shoot()
	{


        do
        {
            Vector3 endOfGun = transform.TransformDirection(new Vector3(0.0f, 0.0f, 4.0f));

            GameObject instance = Instantiate(projectile, transform.position + endOfGun, transform.rotation) as GameObject;
            Rigidbody rg = instance.GetComponent<Rigidbody>();
            rg.velocity = transform.TransformDirection(Vector3.forward * bulletSpeed);


            // wait  3 seconds
            yield return new WaitForSeconds(4.0f);

        } while (true);


        
	}

	IEnumerator Start()
	{

        // Wait 3 seconds to actually start shooting
        yield return new WaitForSeconds(4.0f);
		yield return StartCoroutine("Shoot");
	
	}
}




        
    
