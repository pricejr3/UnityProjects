﻿using UnityEngine;
using System.Collections;

public class OnControllerColliderHitScript : MonoBehaviour {

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Debug.Log("CharacterController hit " + hit.gameObject.name);
    }


}
