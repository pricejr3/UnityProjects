﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

    public GameObject ObjectToSpawn;
    public int totalToSpawn = 10;
    public float spawnInterval = 3.0f;

    public Transform target;


    void Start()
    {
        StartCoroutine(MyCoroutine(target));
    }


    IEnumerator MyCoroutine(Transform target )
    {
        while (totalToSpawn < 20)
        {
           
         
            float randX = Random.Range(-25.0F, 25.0F);
          
            float randY = Random.Range(-25.0F, 25.0F);

            float randHeading = Random.Range(-360.0f, 360.0f);


            Instantiate(ObjectToSpawn, new Vector3(randX, 0.0f, randY), ObjectToSpawn.transform.rotation = Quaternion.Euler(0.0f, randHeading, 0.0f));

            totalToSpawn++;
            yield return new WaitForSeconds(spawnInterval);
        }

        //print("Reached the target.");

       // yield return new WaitForSeconds(3f);

       // print("MyCoroutine is now finished.");
    }
}