﻿using UnityEngine;
using System.Collections;

public class Shooter : MonoBehaviour
{
    public GameObject projectile;
    public float bulletSpeed = 60.0f;


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {

            GameObject rocketInstance;
            rocketInstance = Instantiate(projectile, transform.position, transform.rotation) as GameObject;

            Rigidbody bulletShooting;
            bulletShooting = rocketInstance.GetComponent<Rigidbody>();
            bulletShooting.velocity = transform.TransformDirection(Vector3.forward * bulletSpeed);

            Destroy(rocketInstance, 10.0f);
            
        }
    }
}