﻿using UnityEngine;
using System.Collections;

public class ChangeHeading : MonoBehaviour {


    public float rotationRate = 20.0f;
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKey(KeyCode.LeftArrow))
        {

            transform.Rotate(0, -(Time.deltaTime * rotationRate), 0);
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.Rotate(0, (Time.deltaTime * rotationRate), 0);
        }

	}
}
