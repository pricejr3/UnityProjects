﻿using UnityEngine;
using System;
using System.Collections;

public class ClockScript : MonoBehaviour
{

    public Transform hrs;
    public Transform mins;
    public Transform secs;

    public float noMovement = 0.0f;

    private void Update()
    {
        DateTime time = DateTime.Now;
        hrs.localRotation =
            Quaternion.Euler(noMovement, noMovement, -15.0f * time.Second );
        mins.localRotation =
            Quaternion.Euler(noMovement, noMovement, 9.0f * time.Second);
        secs.localRotation =
            Quaternion.Euler(noMovement, noMovement,  -6.0f * time.Second );
    }
}