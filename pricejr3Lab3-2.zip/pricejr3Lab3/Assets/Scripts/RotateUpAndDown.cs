﻿using UnityEngine;
using System.Collections;

public class RotateUpAndDown : MonoBehaviour {

    public float rotationRate = 20.0f;

   

	// Update is called once per frame
	void Update () {



        float rotateMe = -(Time.deltaTime * rotationRate);
    

        if (Input.GetKey(KeyCode.UpArrow))
        {


            if (-GetPlusMinusAngle(transform.localEulerAngles.x) < 45.0f)
            {
                transform.Rotate(-(Time.deltaTime * rotationRate), 0, 0);
            }

        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {

            if (-GetPlusMinusAngle(transform.localEulerAngles.x) > -45.0f)
            {
                transform.Rotate((Time.deltaTime * rotationRate), 0, 0);
            }
           
        }


	}


    float GetPlusMinusAngle(float angle)
    {
        if (angle > 180)
        {
            return angle - 360;
        }
        else
        {
            return angle;
        }
    }
}
